package com.pokemao.poketrabalho2.restcontrollers;

import com.pokemao.poketrabalho2.entities.Pokemon;
import com.pokemao.poketrabalho2.repositories.PokeList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping(value="/apis")
public class PokeController {
    @Autowired
    private ResourceLoader resourceLoader;

    @Autowired
    private PokeList pokeList;

    @GetMapping(value="/")
    public ResponseEntity<Object> bemVindo() {
        return ResponseEntity.ok("Bem vindo à API de Pokemon");
    }

    @GetMapping(value="/get-pokemon")
    public ResponseEntity<Object> getPokemon(@RequestParam(value="nome") String nome) {
        Pokemon aux = pokeList.getOne(nome);
        if(aux == null)
            return ResponseEntity.badRequest().body("Pokemon não existe");
        else
            return ResponseEntity.ok(aux);
    }

    @GetMapping(value = "/get-by-type/{tipo}")
    public ResponseEntity<Object> getPokemonByType(@PathVariable(value="tipo") String tipo) {
        List<Pokemon> pokemonList = pokeList.getByType(tipo);
        if(pokemonList.isEmpty())
            return ResponseEntity.badRequest().body("Nenhum encontrado");
        else
            return ResponseEntity.ok(pokemonList);
    }

    @PostMapping(value="/add-pokemon")
    public ResponseEntity<Object> addPokemon(@RequestBody Pokemon pokemon) {
        if(pokeList.add(pokemon))
            return ResponseEntity.ok(pokemon);
        else
            return ResponseEntity.badRequest().body("Não é possível cadastrar o pokemon");
    }

    @PostMapping(value="/add-pokemon-img")
    public ResponseEntity<Object> addPokemonImage(String nome, String tipo, String nivel, MultipartFile imagem) {
        Pokemon pokemon = null;
        boolean erro = false;
        try {
            String filename = "" + (new Date().getTime()) + imagem.getOriginalFilename().substring(imagem.getOriginalFilename().lastIndexOf("."));
            Files.copy(imagem.getInputStream(), Paths.get(getStaticPath()).resolve(filename));
            pokemon = new Pokemon(nome, tipo, Integer.parseInt(nivel));
            pokemon.setImagem(filename);
            pokeList.add(pokemon);
        } catch(Exception e) {
            System.out.println(e);
            erro = true;
        }

        if(!erro)
            return ResponseEntity.ok(pokemon);
        else
            return ResponseEntity.badRequest().body("Não é possível cadastrar o pokemon");
    }

    @GetMapping("/poketypes")
    public List<String> getPokemonTypes() {
        return pokeList.getUniqueTypes();
    }

    @GetMapping("/search-pokemon")
    public List<Pokemon> searchPokemon(@RequestParam(value = "namePart", required = false) String namePart) {
        return pokeList.searchByName(namePart);
    }

    public String getStaticPath() throws IOException {
        String staticPath = resourceLoader.getResource("classpath:static").getFile().getAbsolutePath();
        return staticPath;
    }
}
