package com.pokemao.poketrabalho2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PokeTrabalho2Application {

    public static void main(String[] args) {
        SpringApplication.run(PokeTrabalho2Application.class, args);
    }

}
