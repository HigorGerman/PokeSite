document.addEventListener("DOMContentLoaded", function() {
    carregarTipos();
    carregarPokemons();

    document.getElementById("botaoSalvar").addEventListener("click", function() {
        let nomePokemon = document.getElementById("nomePokemon").value;
        let tipoPokemon = document.getElementById("tipo").value;

        if (nomePokemon && tipoPokemon) {
            fetch("http://localhost:8080/apis/add-pokemon", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify({
                    nome: nomePokemon,
                    tipo: tipoPokemon
                })
            })
                .then(response => {
                    if (response.ok) {
                        return response.json();
                    } else {
                        throw new Error("Erro ao cadastrar o Pokémon.");
                    }
                })
                .then(data => {
                    exibirMensagemSucesso("Pokémon cadastrado com sucesso!");
                    carregarPokemons();
                    document.getElementById("nomePokemon").value = "";
                    document.getElementById("tipo").value = "";
                })
                .catch(error => console.error("Erro ao salvar Pokémon: ", error));
        } else {
            alert("Por favor, preencha todos os campos.");
        }
    });

    document.getElementById("filtroNome").addEventListener("input", function() {
        filtrarPokemons();
    });
});

function carregarTipos() {
    fetch("http://localhost:8080/apis/poketypes")
        .then(response => response.json())
        .then(tipos => {
            let selectTipo = document.getElementById("tipo");
            selectTipo.innerHTML = "";
            tipos.forEach(tipo => {
                let option = document.createElement("option");
                option.value = tipo;
                option.textContent = tipo;
                selectTipo.appendChild(option);
            });
        })
        .catch(error => console.error("Erro ao carregar tipos: ", error));
}

function carregarPokemons() {
    fetch("http://localhost:8080/apis/search-pokemon")
        .then(response => response.json())
        .then(pokemons => {
            let tabelaPokemons = document.getElementById("tabelaPokemons").getElementsByTagName("tbody")[0];
            tabelaPokemons.innerHTML = "";

            if (pokemons.length === 0) {
                let row = tabelaPokemons.insertRow();
                let cell = row.insertCell(0);
                cell.colSpan = 2;
                cell.textContent = "Nenhum Pokémon cadastrado.";
                cell.style.textAlign = "center";
            } else {
                pokemons.forEach(pokemon => {
                    let row = tabelaPokemons.insertRow();
                    row.insertCell(0).textContent = pokemon.nome;
                    row.insertCell(1).textContent = pokemon.tipo;

                    row.addEventListener("click", function(event) {
                        event.preventDefault();
                        exibirPopover(pokemon, row);
                    });
                });
            }
        })
        .catch(error => console.error("Erro ao carregar Pokémons: ", error));
}

function exibirPopover(pokemon, element) {
    let popover = document.getElementById("popover");
    if (popover) {
        popover.remove();
    }

    popover = document.createElement("div");
    popover.id = "popover";
    popover.className = "popover";

    popover.innerHTML = `
        <h3>${pokemon.nome}</h3>
        <p>Tipo: ${pokemon.tipo}</p>
        <img src="${pokemon.imagem}" alt="${pokemon.nome}" style="width:100px;height:100px;">
    `;

    document.body.appendChild(popover);
    let rect = element.getBoundingClientRect();
    popover.style.top = `${rect.top + window.scrollY + element.offsetHeight}px`;
    popover.style.left = `${rect.left + window.scrollX}px`;
    popover.style.position = "absolute";
    popover.style.backgroundColor = "#fff";
    popover.style.border = "1px solid #ccc";
    popover.style.padding = "10px";
    popover.style.zIndex = 1000;

    document.addEventListener("click", function(event) {
        if (!popover.contains(event.target) && !element.contains(event.target)) {
            popover.remove();
        }
    }, { once: true });
}

function exibirMensagemSucesso(mensagem) {
    const mensagemDiv = document.createElement("div");
    mensagemDiv.textContent = mensagem;
    mensagemDiv.style.backgroundColor = "#4CAF50";
    mensagemDiv.style.color = "white";
    mensagemDiv.style.padding = "10px";
    mensagemDiv.style.marginTop = "10px";
    mensagemDiv.style.textAlign = "center";
    mensagemDiv.style.borderRadius = "5px";
    document.body.prepend(mensagemDiv);

    setTimeout(() => {
        mensagemDiv.remove();
    }, 3000);
}

function filtrarPokemons() {
    let filtro = document.getElementById("filtroNome").value.toLowerCase();
    let tabelaPokemons = document.getElementById("tabelaPokemons").getElementsByTagName("tbody")[0];
    let linhas = tabelaPokemons.getElementsByTagName("tr");

    for (let i = 0; i < linhas.length; i++) {
        let colunas = linhas[i].getElementsByTagName("td");
        let nomePokemon = colunas[0].textContent.toLowerCase();

        if (nomePokemon.indexOf(filtro) > -1) {
            linhas[i].style.display = "";
        } else {
            linhas[i].style.display = "none";
        }
    }
}
